function updateValue($db, $data) {
    $table = $data['table'];
    $id = $data['id'];
    $params = array();
    $type = array();
    //Start building query
    $query = "UPDATE `$table` SET ";
    //Start building values
    $values = "";
    foreach ($data as $key => $val) {
        if ($key == "table" ||  $key == "action" || $key == "id") {
        } else {
            $values .= $key . "=" . "?,";
            $params[] .= $val;
            $type[0] .= 's';
        }
    }

    //Format and end values
    $values = rtrim($values, ',');
    $values .= " ";
    /*
    At the end of this process, the query looks something like:
    INSERT INTO `lesson_type` (lesson_type) VALUES
    and the values looks something like: 
    (?);

    The reason for the different loops is to work with differently sized tables
    */
    $query = $query . $values . "WHERE ID = ?";
    $params[] .= $id;
    $type[0] .= 'i';

    $query = $db->prepare($query);

    //Creates an array of references to the user inputted parameters for later input
    $refs = array();
    foreach ($params as $key => $value) {
        $refs[$key] = &$params[$key];
    }
    $binding_params = array_merge($type, $refs);

    if ($query == FALSE) {
        echo "sqli_prepare() returned false,\"".$db->error."\"";
    } else {
        //
        call_user_func_array(array($query, 'bind_param'), $binding_params);
        if ($query->execute() ){
            return $result = array(true, $table);
        } else {
            return $result = array(false, $db->error);
        }
    }
    $query->close();
}