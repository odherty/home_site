/**
 *
 *
 * @param {int} notificationID : The clicked on notification's id
 *
 * This function serves as an AJAX request to recieve a database query in JSON data
 */

//Shows the modal box and sets information based on the selected notification
var read_state;
function showModal(notificationID) {
    //Creates a recipient array for later
    var notification = [];
    // If the result is equal to '', which happens at the start when the function is first called at button press
        /* This ajax statement calls getrecipients.php and gives it strNotificationID, the page then grabs
        the recipients of the notification and returns them to the function recursivly */
        $.ajax({
            type: "POST",
            url: "getnotification.php",
            data: {
                notification_id: notificationID
            },
            dataType: 'json',
            success: function (data) {
                notification = data;
                fillModal(notification);
            }
        });
}
/**
 * @param {json} notification : A JSON object retrieved from an AJAX request.
 * @param {string} sender_email : The sender's email retrieved from the original selected notification
 *
 * This function sets all values for the modal box
 */
function fillModal(notification){
        console.log(notification);
        /* When the result is set and the recipients are grabbed, the function goes through setting
        the box's fields */
        var modal = document.getElementById('myModal');
        modal.style.display = "block";

        read_state = notification[0].read_state;

        var modal_category = document.getElementById("modal_category");
        modal_category.className = "fa " + notification[0].icon + " fa-4x note_image";
        modal_category.style = "color: " + notification[0].icon_color;

        var modal_subject = document.getElementById("modal_subject");
        modal_subject.innerHTML = "<strong>Subject: </strong>" + notification[0].subject;

        var modal_sender = document.getElementById("modal_sender");
        modal_sender.innerHTML = "<strong>Sent By: </strong>" + notification[0].email;

        var modal_timestamp = document.getElementById("modal_timestamp");
        var timestamp = new moment(notification[0].timestamp).format('MM/DD/YY hh:ma');
        modal_timestamp.innerHTML = "<strong>Time Sent: </strong>" + timestamp;

        var modal_message = document.getElementById("modal_message");
        modal_message.innerHTML = notification[0].message;

        //If the notification comes with an assignment/activity, it will give the user a link to review it!
        //Buttons
        var modal_buttons = document.getElementById("modal_buttons");
        if (notification[0].submission_link != null) {
            modal_buttons.innerHTML = "<a class = 'btn' href=" + notification[0].submission_link + "?assignment=" + notification[0].assignment_id + ">Go To Activity</a>";
        }
        if (notification[0].read_state == 0) {
            modal_buttons.innerHTML += "<a class='btn btn-archive' href='notification_edit.php?action=archive&id=" + notification[0].notification_id + "'>Archive</a>";
        } else if (notification[0].read_state == 1) {
            modal_buttons.innerHTML += "<a class='btn btn-archive' href='notification_edit.php?action=unread&id=" + notification[0].notification_id + "'>Mark As Unread</a>";
            modal_buttons.innerHTML += "<a class='btn btn-archive' href='notification_edit.php?action=archive&id=" + notification[0].notification_id + "'>Archive</a>";
        } else if (notification[0].read_state == 2) {
            modal_buttons.innerHTML = "<a class='btn btn-archive' href='notification_edit.php?action=restore&id=" + notification[0].notification_id + "'>Restore</a>";
        } else {

        }
}
$(document).ready(function () {

    // Get the modal
    var modal = document.getElementById('myModal');

    // Get the <span> element that closes the modal
    var span = document.getElementsByClassName("close")[0];

    // When the user clicks on <span> (x), close the modal
    span.onclick = function () {
        modal.style.display = "none";
        modal_buttons.innerHTML = null;
        location.href = "notification_list.php"

    }

    // When the user clicks stringwhere outside of the modal, close it
    window.onclick = function (event) {
        if (event.target == modal) {
            modal.style.display = "none";
            modal_buttons.innerHTML = null;
            location.href = "notification_list.php"
        }
    }


});
