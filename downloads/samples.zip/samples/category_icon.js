$(document).ready(function() {
    var icon_output = document.getElementById("icon_preview");
    var icon_input = document.getElementById("icon");
    $(icon_input).keyup(function() {
        console.log("ran");
    icon_output.className = "fa " + icon_input.value + " fa-4x";
    });

    var color_input = document.getElementById("icon_color");
    $(color_input).blur(function() {
        console.log("ran");
        icon_output.style.color = color_input.value;
    });
    $(color_input).keyup(function() {
        console.log("ran");
        icon_output.style.color = color_input.value;
    });
});

function validateForm() {
    var icon = document.forms["itemForm"]["category_icon_box"].value;
    var RegEx = /([fa-]{3})/;
    if (RegEx.test(x) != true) {
        alert("Invalid icon\nStart with 'fa-', use the icon list to find icons");
        return false;
    }
}
